"""
🦅 PROFESSIONAL BIRD & DRONE DETECTION APP 🚁
==============================================
Complete Streamlit Application with Advanced UI
UPDATED: Accepts ANY image type

⚠️ IMPORTANT - SETUP INSTRUCTIONS:
==================================
1. Save this file as: app.py
2. Create a folder called "models" and place your model inside it
3. Install dependencies: pip install streamlit tensorflow pillow numpy opencv-python
4. Update the MODEL_PATH below (line 23)
5. Run: streamlit run app.py
6. Open: http://localhost:8501

📝 CONFIGURATION - UPDATE THIS LINE:
====================================
"""

import streamlit as st
import numpy as np
import cv2
from PIL import Image
from datetime import datetime
import time
import io
import os

# ============ 🔧 CONFIGURATION - CHANGE THIS VALUE ============
MODEL_PATH = "models/bird_drone_classifier_final.h5"  # ⬅️ YOUR MODEL PATH
CONFIDENCE_THRESHOLD = 0.5  # ⬅️ DETECTION CONFIDENCE THRESHOLD (0-1)
CLASS_NAMES = ['Bird', 'Drone']  # ⬅️ YOUR CLASS NAMES
# =================================================================

# Import TensorFlow
try:
    import tensorflow as tf
    from tensorflow import keras
except ImportError:
    st.error("❌ TensorFlow not installed. Run: pip install tensorflow")
    st.stop()

# ============================================================
# 🎨 CUSTOM STYLING
# ============================================================

def apply_styling():
    """Apply professional dark theme CSS"""
    st.markdown("""
    <style>
    /* Root Variables */
    :root {
        --primary-color: #3b82f6;
        --secondary-color: #10b981;
        --danger-color: #ef4444;
        --warning-color: #f59e0b;
        --dark-bg: #0f172a;
        --dark-surface: #1e293b;
        --border-color: #334155;
    }
    
    /* Main Background */
    .main {
        background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
    }
    .stApp {
        background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
    }
    
    /* Header */
    h1 {
        color: #3b82f6 !important;
        text-align: center;
        padding: 25px;
        background: linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(139, 92, 246, 0.1));
        border-radius: 15px;
        border: 2px solid rgba(59, 130, 246, 0.3);
        margin-bottom: 30px;
        text-shadow: 0 2px 10px rgba(0,0,0,0.3);
        font-weight: 800;
    }
    
    h2, h3 {
        color: #94a3b8 !important;
    }
    
    /* Cards & Containers */
    .detection-card {
        background: linear-gradient(135deg, rgba(59, 130, 246, 0.1), rgba(139, 92, 246, 0.1));
        border: 2px solid #334155;
        border-radius: 15px;
        padding: 30px;
        margin: 20px 0;
        text-align: center;
        box-shadow: 0 10px 40px rgba(0,0,0,0.3);
        transition: all 0.3s ease;
    }
    
    .detection-card:hover {
        border-color: #3b82f6;
        box-shadow: 0 15px 50px rgba(59, 130, 246, 0.2);
        transform: translateY(-2px);
    }
    
    .stat-card {
        background: rgba(30, 41, 59, 0.8);
        border: 1px solid #334155;
        border-radius: 12px;
        padding: 20px;
        text-align: center;
        box-shadow: 0 5px 20px rgba(0,0,0,0.2);
    }
    
    /* Buttons */
    .stButton > button {
        background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
        color: white;
        border: none;
        border-radius: 10px;
        padding: 12px 30px;
        font-weight: 600;
        transition: all 0.3s ease;
        box-shadow: 0 4px 15px rgba(59, 130, 246, 0.4);
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    
    .stButton > button:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 25px rgba(59, 130, 246, 0.6);
        background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
    }
    
    .stButton > button:active {
        transform: translateY(-1px);
    }
    
    /* File Uploader */
    [data-testid="stFileUploader"] {
        background: rgba(59, 130, 246, 0.05);
        border: 3px dashed #3b82f6 !important;
        border-radius: 15px;
        padding: 25px;
        transition: all 0.3s ease;
    }
    
    [data-testid="stFileUploader"]:hover {
        background: rgba(59, 130, 246, 0.1);
        border-color: #60a5fa !important;
        box-shadow: 0 0 20px rgba(59, 130, 246, 0.2);
    }
    
    /* Progress Bar */
    .stProgress > div > div > div > div {
        background: linear-gradient(90deg, #3b82f6 0%, #10b981 100%);
        border-radius: 10px;
    }
    
    /* Alerts */
    .stAlert {
        border-radius: 12px;
        border: 1px solid #334155;
    }
    
    .stAlert-success {
        background: rgba(16, 185, 129, 0.1) !important;
        border: 1px solid rgba(16, 185, 129, 0.3) !important;
    }
    
    .stAlert-error {
        background: rgba(239, 68, 68, 0.1) !important;
        border: 1px solid rgba(239, 68, 68, 0.3) !important;
    }
    
    .stAlert-warning {
        background: rgba(245, 158, 11, 0.1) !important;
        border: 1px solid rgba(245, 158, 11, 0.3) !important;
    }
    
    .stAlert-info {
        background: rgba(59, 130, 246, 0.1) !important;
        border: 1px solid rgba(59, 130, 246, 0.3) !important;
    }
    
    /* Metrics */
    [data-testid="stMetricValue"] {
        color: #3b82f6;
        font-size: 2em;
        font-weight: 700;
    }
    
    [data-testid="stMetricLabel"] {
        color: #94a3b8;
    }
    
    /* Images */
    .stImage {
        border-radius: 15px;
        overflow: hidden;
        box-shadow: 0 10px 30px rgba(0,0,0,0.4);
    }
    
    /* Sidebar */
    [data-testid="stSidebar"] {
        background: linear-gradient(180deg, #1e293b 0%, #0f172a 100%);
        border-right: 2px solid #334155;
    }
    
    /* Divider */
    hr {
        border-color: #334155;
    }
    
    /* Expander */
    .streamlit-expanderHeader {
        background: rgba(30, 41, 59, 0.6);
        border-radius: 10px;
        border: 1px solid #334155;
    }
    
    /* Text */
    p, span {
        color: #e2e8f0;
    }
    
    .detection-success {
        color: #10b981;
        font-size: 1.5em;
        font-weight: bold;
    }
    
    .detection-failed {
        color: #ef4444;
        font-size: 1.5em;
        font-weight: bold;
    }
    
    .confidence-high {
        color: #10b981;
    }
    
    .confidence-medium {
        color: #f59e0b;
    }
    
    .confidence-low {
        color: #ef4444;
    }
    </style>
    """, unsafe_allow_html=True)

# ============================================================
# 📦 MODEL LOADING
# ============================================================

@st.cache_resource
def load_detection_model():
    """Load TensorFlow model with error handling"""
    try:
        model = keras.models.load_model(MODEL_PATH)
        return model, True, "✅ Model loaded successfully"
    except FileNotFoundError:
        return None, False, f"❌ Model file not found at: {MODEL_PATH}"
    except Exception as e:
        return None, False, f"❌ Error loading model: {str(e)}"

# ============================================================
# 🎯 DETECTION FUNCTIONS
# ============================================================

def convert_image_to_rgb(image):
    """Convert any image format to RGB"""
    try:
        # If image is RGBA, convert to RGB
        if image.mode == 'RGBA':
            rgb_image = Image.new('RGB', image.size, (255, 255, 255))
            rgb_image.paste(image, mask=image.split()[3])
            return rgb_image
        # If image is grayscale, convert to RGB
        elif image.mode == 'L':
            return image.convert('RGB')
        # If image is already RGB or other color mode
        elif image.mode != 'RGB':
            return image.convert('RGB')
        else:
            return image
    except Exception as e:
        st.error(f"Error converting image: {e}")
        return None

def preprocess_image(image, target_size=(224, 224)):
    """Preprocess image for model prediction - SUPPORTS ANY IMAGE FORMAT"""
    try:
        # Convert to RGB if needed
        image = convert_image_to_rgb(image)
        if image is None:
            return None
        
        # Convert PIL image to numpy array
        img_array = np.array(image)
        
        # Ensure image has correct shape (handle edge cases)
        if len(img_array.shape) == 2:  # Grayscale
            img_array = np.stack([img_array] * 3, axis=-1)
        elif len(img_array.shape) == 3 and img_array.shape[2] == 4:  # RGBA
            img_array = img_array[:, :, :3]
        
        # Resize to target size using CV2
        img_resized = cv2.resize(img_array, target_size)
        
        # Normalize to 0-1 range
        img_normalized = img_resized.astype('float32') / 255.0
        
        # Add batch dimension
        img_batch = np.expand_dims(img_normalized, axis=0)
        
        return img_batch
    
    except Exception as e:
        st.error(f"Error preprocessing image: {e}")
        return None

def predict_detection(model, image):
    """Make prediction on image - ROBUST ERROR HANDLING"""
    try:
        # Preprocess
        img_batch = preprocess_image(image)
        
        if img_batch is None:
            return {
                'success': False,
                'message': "❌ Failed to process image format"
            }
        
        # Predict
        predictions = model.predict(img_batch, verbose=0)
        
        # Get class with highest confidence
        predicted_idx = np.argmax(predictions[0])
        confidence = float(predictions[0][predicted_idx])
        predicted_class = CLASS_NAMES[predicted_idx]
        
        # Get all probabilities
        all_probs = {CLASS_NAMES[i]: float(predictions[0][i]) * 100 for i in range(len(CLASS_NAMES))}
        
        return {
            'class': predicted_class,
            'confidence': confidence,
            'confidence_percent': confidence * 100,
            'probabilities': all_probs,
            'success': True,
            'message': f"✅ Detected: {predicted_class}"
        }
    
    except Exception as e:
        return {
            'success': False,
            'message': f"❌ Detection failed: {str(e)}"
        }

def get_confidence_color(confidence):
    """Get color based on confidence level"""
    if confidence >= 0.8:
        return "#10b981"  # Green - High
    elif confidence >= 0.6:
        return "#f59e0b"  # Orange - Medium
    else:
        return "#ef4444"  # Red - Low

def get_confidence_label(confidence):
    """Get confidence label"""
    if confidence >= 0.8:
        return "🟢 High Confidence"
    elif confidence >= 0.6:
        return "🟡 Medium Confidence"
    else:
        return "🔴 Low Confidence"

# ============================================================
# 🚀 MAIN APP
# ============================================================

def main():
    # Page config
    st.set_page_config(
        page_title="Bird & Drone Detector",
        page_icon="🦅",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    # Apply styling
    apply_styling()
    
    # Load model
    model, model_loaded, model_message = load_detection_model()
    
    # ===== HEADER =====
    col1, col2, col3 = st.columns([1, 2, 1])
    with col2:
        st.markdown("# 🦅 Bird & Drone Detector 🚁")
        st.markdown("### *Advanced AI-Powered Detection System*")
    
    # ===== MODEL STATUS =====
    if not model_loaded:
        st.error(f"⚠️ {model_message}")
        
        with st.expander("📋 SETUP INSTRUCTIONS", expanded=True):
            st.markdown("""
            ### Step 1: Create Folder Structure
            ```
            Your Project Folder/
            ├── app.py  (this file)
            └── models/
                └── your_model.h5  (your trained model)
            ```
            
            ### Step 2: Update Configuration (Line 23)
            Open `app.py` and change:
            ```python
            MODEL_PATH = "models/your_model.h5"  # ⬅️ Change this
            ```
            
            ### Step 3: Install Dependencies
            ```bash
            pip install streamlit tensorflow pillow numpy opencv-python
            ```
            
            ### Step 4: Run the App
            ```bash
            streamlit run app.py
            ```
            
            ### Step 5: Open in Browser
            The app will open automatically at: http://localhost:8501
            """)
        st.stop()
    
    st.success("✅ Model loaded successfully!")
    
    # ===== SIDEBAR - STATISTICS & INFO =====
    with st.sidebar:
        st.header("📊 Session Statistics")
        
        if 'detection_history' not in st.session_state:
            st.session_state.detection_history = []
        
        # Stats
        total_detections = len(st.session_state.detection_history)
        bird_detections = sum(1 for d in st.session_state.detection_history if d['class'] == 'Bird')
        drone_detections = total_detections - bird_detections
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Total", total_detections, label_visibility="visible")
        with col2:
            st.metric("🦅 Birds", bird_detections)
        with col3:
            st.metric("🚁 Drones", drone_detections)
        
        st.markdown("---")
        
        # Model Info
        st.header("📋 Model Information")
        st.info(f"""
        **Status:** ✅ Ready
        **Type:** TensorFlow/Keras
        **Classes:** {', '.join(CLASS_NAMES)}
        **Threshold:** {CONFIDENCE_THRESHOLD * 100:.0f}%
        **Image Support:** ✅ All Formats (JPG, PNG, BMP, GIF, WEBP, etc.)
        """)
        
        st.markdown("---")
        
        # Clear History
        if st.button("🗑️ Clear History", type="secondary", use_container_width=True):
            st.session_state.detection_history = []
            st.rerun()
        
        st.markdown("---")
        
        # Help
        with st.expander("❓ How to Use", expanded=False):
            st.markdown("""
            1. **Upload Image**: Click the upload area
            2. **Any Format**: JPG, PNG, BMP, GIF, TIFF, WEBP, etc.
            3. **Analyze**: Click "Detect Object" button
            4. **View Results**: See detection and confidence
            5. **History**: Check past detections in sidebar
            """)
    
    st.markdown("---")
    
    # ===== MAIN CONTENT =====
    col1, col2 = st.columns([1, 1], gap="large")
    
    # ===== LEFT COLUMN - UPLOAD & IMAGE =====
    with col1:
        st.markdown("### 📤 Upload Image")
        
        # Accept all image formats
        uploaded_file = st.file_uploader(
            "Drag and drop or click to select ANY image",
            type=['jpg', 'jpeg', 'png', 'bmp', 'gif', 'tiff', 'webp', 'ico'],
            label_visibility="collapsed"
        )
        
        if uploaded_file is not None:
            try:
                # Open and display image
                image = Image.open(uploaded_file)
                st.image(image, caption="📸 Uploaded Image", use_container_width=True)
                
                # Image info
                st.caption(f"📁 File: {uploaded_file.name} | 📏 Size: {uploaded_file.size / 1024:.1f} KB | 🖼️ Format: {image.format}")
                
                st.markdown("---")
                
                # Detection button
                if st.button("🔍 Detect Object", type="primary", use_container_width=True, key="detect_btn"):
                    with st.spinner("⏳ Analyzing image..."):
                        # Progress
                        progress_bar = st.progress(0)
                        
                        for i in range(100):
                            time.sleep(0.01)
                            progress_bar.progress(i + 1)
                        
                        # Make prediction
                        result = predict_detection(model, image)
                        
                        # Store in history
                        if result['success']:
                            st.session_state.detection_history.insert(0, {
                                'class': result['class'],
                                'confidence': result['confidence'],
                                'timestamp': datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                                'file': uploaded_file.name
                            })
                        
                        # Display result in right column
                        st.session_state.last_result = result
                        st.rerun()
            
            except Exception as e:
                st.error(f"❌ Error loading image: {str(e)}")
                st.info("Try a different image format or check the file integrity")
        
        else:
            st.info("👆 Upload any image format (JPG, PNG, BMP, GIF, WEBP, TIFF, etc.)")
    
    # ===== RIGHT COLUMN - RESULTS =====
    with col2:
        st.markdown("### 📊 Detection Results")
        
        if 'last_result' in st.session_state:
            result = st.session_state.last_result
            
            if result['success']:
                confidence = result['confidence']
                confidence_percent = result['confidence_percent']
                predicted_class = result['class']
                
                # Determine emoji and color
                emoji = "🦅" if predicted_class == "Bird" else "🚁"
                color = "#10b981" if predicted_class == "Bird" else "#f59e0b"
                
                # Main detection result
                st.markdown(f"""
                <div class="detection-card">
                    <h2 style="color: {color}; margin: 0; font-size: 3em;">
                        {emoji}
                    </h2>
                    <h1 style="color: {color}; margin: 10px 0;">
                        {predicted_class}
                    </h1>
                    <p style="color: #e2e8f0; font-size: 1.2em; margin: 0;">
                        Detected Successfully ✅
                    </p>
                </div>
                """, unsafe_allow_html=True)
                
                # Confidence display
                col1, col2 = st.columns(2)
                
                with col1:
                    st.metric("Confidence", f"{confidence_percent:.2f}%")
                    
                with col2:
                    conf_color = get_confidence_color(confidence)
                    st.markdown(f"<p style='color: {conf_color}; font-weight: bold;'>{get_confidence_label(confidence)}</p>", unsafe_allow_html=True)
                
                # Confidence progress bar
                st.progress(confidence)
                
                # Detailed probabilities
                st.markdown("#### 📈 Class Probabilities")
                
                for class_name, prob in result['probabilities'].items():
                    col1, col2 = st.columns([1, 3])
                    with col1:
                        st.markdown(f"**{class_name}**")
                    with col2:
                        st.progress(prob / 100.0)
                        st.caption(f"{prob:.2f}%")
                
                # Timestamp
                st.caption(f"⏱️ Detected at: {datetime.now().strftime('%H:%M:%S')}")
                
                # Decision
                st.markdown("---")
                if confidence >= CONFIDENCE_THRESHOLD:
                    st.success(f"✅ **Confirmed Detection**: {predicted_class} (Confidence: {confidence_percent:.1f}%)")
                else:
                    st.warning(f"⚠️ **Low Confidence**: Detection may be inaccurate. Try a clearer image.")
            
            else:
                st.error(result['message'])
        
        else:
            st.info("👈 Upload and analyze an image to see results")
    
    # ===== DETECTION HISTORY =====
    st.markdown("---")
    st.markdown("### 📜 Detection History")
    
    if st.session_state.detection_history:
        for i, detection in enumerate(st.session_state.detection_history[:5]):
            emoji = "🦅" if detection['class'] == "Bird" else "🚁"
            
            col1, col2, col3, col4 = st.columns([1, 2, 2, 2])
            
            with col1:
                st.markdown(f"## {emoji}")
            
            with col2:
                st.markdown(f"**{detection['class']}**")
                st.caption(detection['file'])
            
            with col3:
                st.markdown(f"**{detection['confidence'] * 100:.1f}%**")
                st.caption("Confidence")
            
            with col4:
                st.markdown(detection['timestamp'])
                st.caption("Time")
            
            st.markdown("---")
    
    else:
        st.info("📭 No detection history yet")
    
    # ===== FOOTER - ADVANCED INFO =====
    st.markdown("---")
    
    with st.expander("🔧 Advanced Settings & Information", expanded=False):
        st.markdown("""
        ### Configuration Details
        
        | Setting | Value |
        |---------|-------|
        | **Model Path** | `models/bird_drone_classifier_final.h5` |
        | **Confidence Threshold** | `0.5` (50%) |
        | **Image Size** | `(224, 224)` pixels |
        | **Classes** | Bird, Drone |
        | **Framework** | TensorFlow/Keras |
        | **Image Formats Supported** | JPG, PNG, BMP, GIF, TIFF, WEBP, ICO |
        
        ### Supported Image Formats
        
        ✅ **JPEG/JPG** - Compressed format, good for photos
        ✅ **PNG** - Lossless, supports transparency
        ✅ **BMP** - Uncompressed, large file size
        ✅ **GIF** - Animated or static images
        ✅ **TIFF** - High quality, often used professionally
        ✅ **WEBP** - Modern format, good compression
        ✅ **ICO** - Icon format
        
        ### Model Troubleshooting
        
        **If model doesn't load:**
        - ✓ Check model file path is correct
        - ✓ Verify model file exists in `models/` folder
        - ✓ Ensure model is compatible with TensorFlow
        
        **If predictions are wrong:**
        - ✓ Ensure image is clear and well-lit
        - ✓ Check model was trained properly
        - ✓ Verify input size matches training data (224x224)
        
        **If image format not accepted:**
        - ✓ Try converting to PNG or JPG
        - ✓ Check file extension is correct
        - ✓ Ensure file is not corrupted
        
        **Dependencies installed:**
        - ✓ streamlit
        - ✓ tensorflow
        - ✓ pillow (for image handling)
        - ✓ numpy
        - ✓ opencv-python (for image processing)
        """)

if __name__ == "__main__":
    main()
